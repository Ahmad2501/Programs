"""
Flask: Using templates
"""
from mimetypes import init
from multiprocessing import connection
import random

import mysqlx
from setup_db import init_students, select_students, select_courses, select_grades, add_student, select_courses_by_id, select_students_by_grades, add_grade
import sqlite3
from flask import Flask, render_template, request, flash,redirect, url_for, g

app = Flask(__name__)


DATABASE = './database.db'


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()


@app.route("/")
def index():
    # get the database connection
    conn = get_db()

    return render_template("index.html",
                    # select_students executes SELECT SQL statement on database connetion
                    # returns list of students
                    students=select_students(conn), courses= select_courses(conn))
                   


    
@app.route("/new_student")
def new_student():
    return render_template("add_student.html")

@app.route("/student", methods=["POST"])
def create_student():
    conn = get_db()    
    name = request.form['name']
 
    
    if name !="":
           student_no = random.randint(100000,999999)
           add_student(conn, student_no, name)       
    else:
        msg= "studenten ikke addet"
        return render_template("add_student.html", msg=msg)
    return redirect(url_for("index"))
        
@app.route("/student/<student_no>")
def student(student_no):
    conn= get_db()
    
    return render_template("students.html", students=select_students (conn), student_no=int(student_no) ,grades= select_students_by_grades(conn, student_no))
# Add additional routes here.

@app.route("/course/<course_id>")
def course(course_id):
    conn = get_db()
    select_grades(conn)
  
    return render_template("courses.html", course=select_courses (conn), course_id=course_id ,grades= select_grades(conn))



@app.route("/add_grade", methods=['GET', 'POST'])
def addgrade():
    conn = get_db()
    if request.method =='POST':
        grade= request.form['grade']
        course = request.form['course']
        student_no = request.form['stud']
     
        if grade != "" or course !="" or student_no !="":
          
            add_grade(conn, course, student_no, grade)


            return render_template("add_grad.html", courses= select_courses(conn), grades= select_grades(conn), students=select_students(conn), msg= "new grade for the student")
        else:
            return render_template("add_grad.html", courses= select_courses(conn), grades= select_grades(conn), students=select_students(conn), msg="faild added grade")
    
    else:
        return render_template("add_grad.html", courses= select_courses(conn), grades= select_grades(conn), students=select_students(conn))


if __name__ == "__main__":
    app.run(debug=True)