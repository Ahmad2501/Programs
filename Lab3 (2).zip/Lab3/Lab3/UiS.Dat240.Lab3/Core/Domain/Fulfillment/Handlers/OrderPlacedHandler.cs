using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Events;
using UiS.Dat240.Lab3.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;

namespace UiS.Dat240.Lab3.Core.Domain.Fulfillment.Handlers{

public class OrderPlacedHandler : INotificationHandler<OrderPlaced>
{
	private readonly ShopContext _db;

	public OrderPlacedHandler(ShopContext db)
		=> _db = db ?? throw new System.ArgumentNullException(nameof(db));

	public async Task Handle(OrderPlaced notification, CancellationToken cancellationToken)
	{
		var orderen = await _db.Orders.Include(c => c.Customer)
									.Include(c => c.Location)
									.Include(c => c.OrderLines)
									.Where(o => o.Id == notification.OrderId).SingleOrDefaultAsync();
		

		Offer offer = new();
		offer.OrderId = notification.OrderId;
		offer.Shipper = new();
		decimal amount = 0.0M;
		foreach(var item in orderen.OrderLines)
			amount += item.Price * item.Amount;
		Reimbursement r = new();
		r.Amount = amount;
		offer.Reimbursement = r;
		_db.Offers.Add(offer);
		await _db.SaveChangesAsync(cancellationToken);
	}
}
}