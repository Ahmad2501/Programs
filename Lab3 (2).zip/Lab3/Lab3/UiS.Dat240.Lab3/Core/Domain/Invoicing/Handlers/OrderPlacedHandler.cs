using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Events;
using UiS.Dat240.Lab3.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
namespace UiS.Dat240.Lab3.Core.Domain.Invoicing.Handlers{

public class OrderPlacedHandler : INotificationHandler<OrderPlaced>
{
	private readonly ShopContext _db;

	public OrderPlacedHandler(ShopContext db)
		=> _db = db ?? throw new System.ArgumentNullException(nameof(db));

	public async Task Handle(OrderPlaced notification, CancellationToken cancellationToken)
	{
		var orderen = await _db.Orders.Include(c => c.Customer)
									.Include(c => c.Location)
									.Include(c => c.OrderLines)
									.Where(o => o.Id == notification.OrderId).SingleOrDefaultAsync();
		decimal amount = 0.0M;
		foreach(var item in orderen.OrderLines){
			amount += item.Price * item.Amount;
		}
		Address address = new(orderen.Location.Building, orderen.Location.RoomNumber, orderen.Location.Notes);
		Customer customer = new(orderen.Customer.Id, orderen.Customer.Name);
		Invoice invoice = new();
		invoice.OrderId = orderen.Id;
        invoice.Address = address;
        invoice.Amount = amount;
        invoice.Customer = customer;
        invoice.Status = Status.Placed;
		_db.Invoices.Add(invoice);
		await _db.SaveChangesAsync(cancellationToken);
	}
}
}