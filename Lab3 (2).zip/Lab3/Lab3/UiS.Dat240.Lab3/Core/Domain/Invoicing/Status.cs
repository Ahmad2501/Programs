namespace UiS.Dat240.Lab3.Core.Domain.Invoicing{

    public enum Status{
        New,
        Placed,
        Shipped,
        Delivered,
        Missing,
        Declined
    }
}