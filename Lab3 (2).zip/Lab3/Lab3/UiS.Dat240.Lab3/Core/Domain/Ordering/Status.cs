
namespace UiS.Dat240.Lab3.Core.Domain.Ordering
{

    public enum Status{
        New,
        Placed,
        Shipped,
        Paid,
        Overdue,
        Credited
    }
}