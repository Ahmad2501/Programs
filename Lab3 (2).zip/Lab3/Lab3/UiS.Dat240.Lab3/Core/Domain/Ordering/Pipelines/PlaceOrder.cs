using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using UiS.Dat240.Lab3.Infrastructure.Data;
using MediatR;
using Microsoft.EntityFrameworkCore;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Dto;
using UiS.Dat240.Lab3.Core.Domain.Ordering.Events;

namespace UiS.Dat240.Lab3.Core.Domain.Ordering.Pipelines{

	public class PlaceOrder
	{
		public record Request(
			Location location, string name, OrderLineDto[] orderLines) : IRequest<Order>;

		public record Response(bool Success, string[] Errors);

		public class Handler : IRequestHandler<Request, Order>
		{
			private readonly ShopContext _db;

			public Handler(ShopContext db) => _db = db ?? throw new ArgumentNullException(nameof(db));

			public async Task<Order> Handle(Request request, CancellationToken cancellationToken)
			{
				Order order = new();
				order.Location = request.location;
				order.Status = Status.Placed;
				foreach(var item in request.orderLines){
					order.AddOrderLine(item);
				}
				var customer = await _db.Orders.Select(o => o.Customer).Where(o => 
									o.Name == request.name).Take(1).SingleOrDefaultAsync();
				if (customer == null)
					customer = new Customer(request.name);
				order.Customer = customer;
				_db.Orders.Add(order);
				await _db.SaveChangesAsync(cancellationToken);
				var orderen = await _db.Orders.OrderByDescending(o => o.OrderDate).Take(1).SingleOrDefaultAsync(); 
				orderen.Events.Add(new OrderPlaced(orderen.Id));
				await _db.SaveChangesAsync(cancellationToken);
				return orderen;
			}
		}
	}
}