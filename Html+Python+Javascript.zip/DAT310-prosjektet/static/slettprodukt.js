function slettProdukt(produktId) {
    // Opprett en XMLHttpRequest-forespørsel
    var xhr = new XMLHttpRequest();

    // Angi metode og URL for forespørselen
    xhr.open('POST', '/slett_produkt', true);

    // Angi content type for forespørselen
    xhr.setRequestHeader('Content-Type', 'application/json');

    // Definer hva som skal skje når forespørselen er fullført
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Produktet ble slettet, oppdater grensesnittet
            var produktElement = document.querySelector('tr[data-produkt-id="' + produktId + '"]');
            if (produktElement) {
                produktElement.parentNode.removeChild(produktElement);
            } else {
                console.log('Feil: Elementet ble ikke funnet');
            }
        } else {
            // Noe gikk galt
            console.log('Feil under sletting av produkt');
        }
    };

    // Send forespørselen med produktets ID som JSON-data
    xhr.send(JSON.stringify({ produkt_id: produktId }));
}

// Lytter etter klikkshendelser på slettknappene
var deleteButtons = document.getElementsByClassName('delete-button');
for (var i = 0; i < deleteButtons.length; i++) {
    deleteButtons[i].addEventListener('click', function() {
        var produktId = this.getAttribute('data-produkt-id');
        slettProdukt(produktId);
    });
}