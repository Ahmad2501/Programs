function checkPassword(passord) {
    // sjekker at passordet er større en 8 og inneholder mist en tall og en bokstav
    if (passord.length < 8 || !/\d/.test(passord) || !/[a-zA-Z]/.test(passord)) {
      alert("Passordet må inneholde minst 8 tegn og være en kombinasjon av tall og bokstaver");
      return false;
    }
    // gjør passordet til json
    var data = JSON.stringify({ "passord": passord });
  
    //oppretter XMLHttpRequest-forespørsel
    var xhr = new XMLHttpRequest();
    //sende HTTP forespørsel til valdate_password 
    xhr.open("POST", "/validate_password", true);
    // trenges fordi vi bruker post, den sier at forespørsel inneholder json
    xhr.setRequestHeader("Content-Type", "application/json");
    //sender data til serveren nå
    xhr.send(data);
  
    // ta imot svar
    xhr.onreadystatechange = function() {
      if (xhr.readyState === XMLHttpRequest.DONE) {
        // hvis XMLHttpRequest request blei vellykket sendt 
        if (xhr.status === 200) {
          // parse gjør at data er blir javascript
          var response = JSON.parse(xhr.responseText);
          if (!response.valid) {
            alert(response.message);
          } else {
            document.getElementById("registration-ins").submit();
          }
        }
        else {
          alert("Feil med ajax forespørsel");
        }
      }
    };
  
    return false;
  }