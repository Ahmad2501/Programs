import sqlite3
from flask import Flask, render_template, request, flash, redirect, url_for, g, session, make_response, jsonify
import bcrypt
import re
app = Flask(__name__)

DATABASE = './database.db'


def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
    return db



@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()



@app.route('/')    
@app.route('/login', methods=['GET', 'POST'])
def login():
    conn = get_db()
    msg = ""

    if request.method == 'POST':
        brukernavn = request.form.get('brukernavn')
        passord = request.form.get('passord')  

        cur = conn.cursor()
        cur.execute('SELECT * FROM brukere WHERE brukernavn = ?', (brukernavn,))
        bruker = cur.fetchone()
        if bruker:
            hashed_password = bruker[2]
            if bcrypt.checkpw(passord.encode('utf-8'), hashed_password):
                session['loggedin'] = True
                session['id'] = bruker[0]
                session['username'] = bruker[1]
                session['rolle'] = bruker[3]
                msg = 'logget inn vellykket!'
                if bruker[3] == 'kunde':
                    return redirect(url_for('kunde'))
                elif bruker[3] == 'admin':
                    return redirect(url_for('admin'))
            
            else:
                msg = 'Ikke riktig passord!'
        else:
            msg = 'Brukeren finnes ikke!'
    return render_template('login.html', msg=msg)

@app.route("/register")
def ny_bruker():
    return render_template("register.html")

@app.route("/register", methods=["POST"])
def register():
    conn = get_db()
    brukernavn = request.form['brukernavn']
    passord = request.form['passord']
    gjpass = request.form['passord-gjentakelse']
    if passord == gjpass:
        bits = passord.encode('utf-8')
        salt = bcrypt.gensalt()
        hashed_passord = bcrypt.hashpw(bits, salt)
        cur = conn.cursor()
        cur.execute('DELETE FROM brukere WHERE brukernavn=?', (brukernavn,))
        conn.commit()
        cur.execute('INSERT INTO brukere(brukernavn, passord, rolle) VALUES(?,?,?)', (brukernavn, hashed_passord, 'kunde'))
        conn.commit()
        return redirect(url_for('login'))
    else:
        flash("Passordet må være lik gjentakelse")
    return redirect(url_for('register'))

@app.route("/validate_password", methods=["POST"])
def validate_password():
    #få passwordet fra json 
    passord = request.json.get("passord")
    if len(passord)< 8:
        if re.search(r'\d', passord) or not re.search(r'[a-zA-Z]', passord):
            response = {"valid": False, "message": "Passordet må inneholde minst 8 tegn og være en kombinasjon av tall og bokstaver"}

    else:
        response = {"valid": True}
    return jsonify(response)

@app.route('/rolle')
def rolle():
    rolle = session.get("rolle")
    if rolle == "admin":
        return render_template('admin.html')
    elif rolle == "kunde":
        return render_template('kunde.html')
    else:
        return redirect('/login')
    
@app.route('/admin')
def admin():
    conn = get_db()
    cur = conn.cursor()
    cur.execute('SELECT * FROM produkter')
    produkter = cur.fetchall()
    return render_template('admin.html', produkter=produkter)



@app.route('/add_produkt', methods=['GET', 'POST'])
def add_produkt():
    conn = get_db()
    if request.method=="POST":
       tittel = request.form['tittel']
       bilde = request.form['bilde']
       kategori = request.form['kategori']
       cur = conn.cursor()
       cur.execute('INSERT INTO produkter (tittel, bilde, kategori) VALUES (?, ?, ?)', (tittel, bilde, kategori))
       conn.commit()
       flash("produktet ble lagt til")
       return(redirect(url_for('admin')))
    else:
        return render_template('add_produkt.html')

@app.route('/delete_produkt', methods=['POST'])
def delete_produkt():
    conn = get_db()
    produkt_id = request.form['produkt_id']
    cur = conn.cursor()
    cur.execute('DELETE FROM produkter WHERE id = ?', (produkt_id,))
    conn.commit()
    flash("Produktet ble slettet")
    return redirect(url_for('admin'))

@app.route('/edit_produkt', methods=['POST', 'GET'])
def edit_produkt():
    conn= get_db()
    cur = conn.cursor()
    if request.method =="POST":
        produkt_id = request.form['produkt_id']
        cur.execute(' SELECT * FROM produkter WHERE id = ?', (produkt_id,))
        produkt = cur.fetchone()
        if produkt:
            return render_template('edit.html', produkt=produkt)
        else: 
            return redirect(url_for('admin'))
        
@app.route('/update_produkt', methods=['POST'])
def update_produkt():
    conn = get_db()
    cur = conn.cursor()

    produkt_id = request.form['produkt_id']
    tittel = request.form['tittel']
    bilde = request.form['bilde']
    kategori = request.form['kategori']

    cur.execute('UPDATE produkter SET tittel=?, bilde=?, kategori=? WHERE id=?',
                (tittel, bilde, kategori, produkt_id))
    conn.commit()

    flash('Product updated successfully')
    return redirect(url_for('admin'))

@app.route('/kunde', methods=['GET', 'POST'])
def kunde():
    conn = get_db()
    cur = conn.cursor()
    if request.method == 'POST': 
        kategori = request.form.get('kategori')
        if kategori:
            cur.execute('SELECT * FROM produkter WHERE kategori = ?',(kategori,))
            res = make_response(render_template('kunde.html',produkter = cur.fetchall()))
            res.set_cookie('kategori',kategori)
            return res
        else: 
            cur.execute('SELECT * FROM produkter')
    else: 
        cur.execute('SELECT * FROM produkter')
        kate_cookie = request.cookies.get('kategori')
        if kate_cookie:
             cur.execute('SELECT * FROM produkter WHERE kategori = ?', (kate_cookie,))
        else:
            cur.execute('SELECT * FROM produkter')

        
    produkter = cur.fetchall()     
    return render_template('kunde.html', produkter=produkter, brukernavn=session['username'])

@app.route('/handelkurv', methods=['POST'])
def handelkurv():
    conn = get_db()
    cur = conn.cursor()
    if request.method=="POST":
        produkt_id = request.form.get('produkt_id')
        cur.execute('SELECT * FROM produkter WHERE id = ?',(produkt_id,))
        produkt = cur.fetchone()
        if produkt:
            cur.execute('''
            INSERT INTO handelkurv (brukernavn, produkt_id, tittel, bilde, kategori)
            VALUES(?, ?, ?, ?, ?)
            ''', (session['username'], produkt_id, produkt[1], produkt[2], produkt[3]))
            conn.commit()
            flash('produktet ble lagt til')
            redirect(url_for('kunde'))
        else:
            flash("Produktet ble ikke lagt til")
   
    cur.execute('SELECT * FROM handelkurv')
    handelkurv = cur.fetchall()
    return(render_template("handelkurv.html", handelkurv=handelkurv))

@app.route('/slett_produkt', methods=['POST'])
def slett_produkt():
    conn = get_db()
    cur = conn.cursor()
    #Få produktets ID fra forespørselen
    produkt_id = request.json.get('produkt_id')

    # Slett produktet fra handlekurven
    cur.execute('DELETE FROM handelkurv WHERE id = ?', (produkt_id,))
    conn.commit()

    return jsonify({'message': 'Produktet ble slettet'})








if __name__ == "__main__":
     with app.app_context():
        conn = get_db()
        cur = conn.cursor()
        cur.execute('''
        CREATE TABLE IF NOT EXISTS brukere (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            brukernavn TEXT UNIQUE,
            passord TEXT,
            rolle TEXT
        )
        ''')
        cur.execute('''
        CREATE TABLE IF NOT EXISTS produkter (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tittel TEXT,
            bilde TEXT,
            kategori TEXT
        )
        ''')

        cur.execute(''' 
        CREATE TABLE IF NOT EXISTS handelkurv (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            brukernavn TEXT REFERENCES brukere(brukernavn),
            tittel TEXT,
            bilde TEXT,
            kategori TEXT,
            produkt_id INTEGER REFERENCES produkter(id)
        )
        ''')
        cur.execute('SELECT * FROM brukere WHERE brukernavn=?', ('admin',))
        admin_bruker = cur.fetchone()
        if admin_bruker is None:
            cur.execute('DELETE FROM brukere WHERE brukernavn=?', ('admin',))
            admin_password = "admin3456"  
            bits = admin_password.encode('utf-8')
            salt = bcrypt.gensalt()
            hash_password = bcrypt.hashpw(bits, salt)
            cur.execute('INSERT INTO brukere(brukernavn, passord, rolle) VALUES(?,?,?)', ('admin', hash_password, 'admin'))
           


            conn.commit()
        app.secret_key = "12341234"
        app.run(debug=True)