using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace UiS.Dat240.Lab2;


public class FProvider: IFoodItemProvider
{
    private readonly ShopContext _db;
    public FProvider(ShopContext db){
        _db = db;
    }
 
    public async Task<FoodItem[]> GetItems(){
        return await _db.Foodi.ToArrayAsync();
    }
    public async Task AddFoodItem(FoodItem item){
        await _db.Foodi.AddAsync(item);
        await _db.SaveChangesAsync();
    }
    
    public async Task<FoodItem> GetFoodItem(int id){
        return await _db.Foodi.FindAsync(id);
    }

    public async Task RemoveFoodItem(int id){
        var vare = await _db.Foodi.FindAsync(id);
        if (vare == null)
            return;
        _db.Foodi.Remove(vare);
        await _db.SaveChangesAsync();
    }
    
    public async Task UpdateFoodItem(int id, FoodItem item){
        var oldItem = await _db.Foodi.FirstOrDefaultAsync(item => item.Id == id);
        if(oldItem != null){
            oldItem.Name = item.Name;
            oldItem.Description = item.Description;
            oldItem.Price = item.Price;
            oldItem.CookTime = item.CookTime;
        }
        await _db.SaveChangesAsync();
        
    }
}