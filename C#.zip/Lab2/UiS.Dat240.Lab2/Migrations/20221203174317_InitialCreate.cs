﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace UiS.Dat240.Lab2.Migrations
{
    public partial class InitialCreate : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Foodi",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", maxLength: 15, nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", unicode: false, maxLength: 30, nullable: false),
                    Description = table.Column<string>(type: "TEXT", unicode: false, maxLength: 200, nullable: false),
                    Price = table.Column<double>(type: "REAL", unicode: false, maxLength: 10, nullable: false),
                    CookTime = table.Column<int>(type: "INTEGER", unicode: false, maxLength: 10, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Foodi", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Foodi");
        }
    }
}
