namespace UiS.Dat240.Lab2;
public class Shservices{
    private readonly IFoodItemProvider _provider;
    private readonly IFoodItemValidator _validator;
    public Shservices(IFoodItemProvider provider, IFoodItemValidator validator)
    {
        _provider = provider;
        _validator = validator;
    }

    public string[] getErrors(){
        FoodItem nvare = new FoodItem();
        string [] errors = _validator.IsValid(nvare);
        return errors; 
    }
}