﻿using Microsoft.EntityFrameworkCore;

namespace UiS.Dat240.Lab2;

// This class should inherit from the EntityFramework DbContext
public class ShopContext : DbContext
{
    public ShopContext(DbContextOptions <ShopContext> options) 
        : base(options)
        {
        }
    public DbSet<FoodItem> Foodi { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<FoodItem>(entity =>
        {
            entity.Property(e => e.Id)
                .IsRequired()
                .HasMaxLength(15)
                .IsUnicode(true);

            entity.Property(e => e.Name)
                .IsRequired()
                .HasMaxLength(30)
                .IsUnicode(false);

            entity.Property(e => e.Description)
                .IsRequired()
                .HasMaxLength(200)
                .IsUnicode(false);

            entity.Property(e => e.Price)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false);

            entity.Property(e=> e.CookTime)
                .IsRequired()
                .HasMaxLength(10)
                .IsUnicode(false);
        });
    }
}

