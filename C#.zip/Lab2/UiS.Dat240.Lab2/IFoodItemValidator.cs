﻿namespace UiS.Dat240.Lab2;


public interface IFoodItemValidator
{
    string[] IsValid(FoodItem foodItem);
}
public class Fvalidator : IFoodItemValidator{
 public string[] IsValid(FoodItem foodItem){

        List<String> errors = new List<String>();

        if(String.IsNullOrEmpty(foodItem.Name))
            errors.Add("illegal Name");

        if(foodItem.Price <= 0)
            errors.Add("Illegal, you can't have a price less than 0");
        
        if(String.IsNullOrEmpty(foodItem.Description))
            errors.Add("Illegal Description");
  
        
        return errors.ToArray();
    }
}