using Microsoft.AspNetCore.Mvc.RazorPages;

using Microsoft.AspNetCore.Mvc;

namespace UiS.Dat240.Lab2.Pages;
public class EditModel : PageModel
{
    private readonly IFoodItemProvider itemProvider;
    private readonly IFoodItemValidator itemValidator;

    public EditModel(IFoodItemProvider provider, IFoodItemValidator validator)
    {
        itemProvider = provider;
        itemValidator = validator;
    }
    public int id;
    public string[]? errors;
    public Boolean has_errors;
    public IActionResult OnGet(int id)
    {
        return Page();
       
    }

    [BindProperty]
    public FoodItem? foodItem { get; set; }

    public async Task<IActionResult> OnPostAsync(int id)
   
    {
         errors = itemValidator.IsValid(foodItem);

        if (!ModelState.IsValid||errors.Length > 0)
        {
            has_errors= true;
            return Page();
        }

        if (foodItem != null) 
            await itemProvider.UpdateFoodItem(id, foodItem);

        return RedirectToPage("./Index");
    }
}
