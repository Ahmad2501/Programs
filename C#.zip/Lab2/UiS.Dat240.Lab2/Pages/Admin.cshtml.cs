using Microsoft.AspNetCore.Mvc.RazorPages;
namespace UiS.Dat240.Lab2.Pages;
using Microsoft.AspNetCore.Mvc;
public class AdminModel : PageModel{
    private readonly ILogger<AdminModel> _logger;
   
    public IEnumerable<FoodItem> FoodItems{ get; set; } = default!;
    public IFoodItemProvider _fooditemprovider;
    public AdminModel(ILogger<AdminModel> logger, IFoodItemProvider foodprovider){
        _logger = logger;
        _fooditemprovider = foodprovider;
    }
    

    public async Task OnGetAsync(){
        
        FoodItems = await _fooditemprovider.GetItems();
             
        
    }
}