using Microsoft.AspNetCore.Mvc.RazorPages;
namespace UiS.Dat240.Lab2.Pages;
using Microsoft.AspNetCore.Mvc;
public class CreateModel : PageModel
{
    private readonly IFoodItemProvider itemProvider;
    private readonly IFoodItemValidator itemValidator;
    public string[]? errors;
    public Boolean has_errors;

    public CreateModel(IFoodItemProvider provider, IFoodItemValidator validator)
    {
        itemProvider = provider;
        itemValidator = validator;
    }

    public IActionResult OnGet()
    {
        return Page();
    }

    [BindProperty]
    public FoodItem? foodItem { get; set; }

    public async Task<IActionResult> OnPostAsync()
    {
        
        errors = itemValidator.IsValid(foodItem);

        if (!ModelState.IsValid||errors.Length > 0)
        {
            has_errors= true;
            return Page();
        }
        if (foodItem != null) 
            await itemProvider.AddFoodItem(foodItem);

        return RedirectToPage("./Index");
    }
}