a = [1,2,4,77,44,33]

for i in a:
    if a[i] ==1 and a[i] == 44:
        print("Funker")
