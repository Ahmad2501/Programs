from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
from .models import Note
from . import db
import json
import random
views = Blueprint('views', __name__)


@views.route('/', methods=['GET', 'POST'])
@login_required
def home():
    if request.method == 'POST':
        #bool bryter = False
        tabell_note = db.session.query(Note.user_id)
        sender = request.form.get("sender")
        mottaker = request.form.get("resiver")#If string is not empty
        betaling = request.form.get("payment")


        #Er bugga igjen aktiviserer uønsket kodeblokk.
        #sjekk om kontoene er i databaen
        #sjekk hvis sender har stort nokk kontoverdi
        #hvis tilfellet, konverter og manipuler databasen


        #Update: Fiksa buggen, tar nå inn inndata
        if len(sender)<1 and len(mottaker) <1 and len(betaling)< 1:#feil her, bugen er her
            number_accounts = 0
            for notes in tabell_note:
                if notes.user_id == current_user.id:
                    number_accounts = number_accounts + 1

            if number_accounts >=5:#and bool = false
                flash('Maximun account number reached, please delete at least one account', category='success')
            else:#elif bool her false, noe galt her denne er bugga lager konto når den ikke skal
                account_random = random.randint(1000,100000)#denne krasjer, nei, funker som faen
                new_note = Note(data=account_random, user_id=current_user.id)
                db.session.add(new_note)
                db.session.commit()
                flash('Account added!', category='success')

        else:
            if(sender[0] is not " " and mottaker[0] is not " " and betaling[0] is not " "):
                if(sender[0] != "0" and mottaker[0] != "0" and betaling[0] != "0"):
                    if(sender.isdecimal() and mottaker.isdecimal() and betaling.isdecimal()):
                        sender_int = int(sender)
                        mottaker_int = int(mottaker)
                        betaling_int = int(betaling)



                        if sender_int > 0 and mottaker_int > 0 and betaling_int > 0:
                            sender_info = Note.query.filter_by(id = sender_int).first()
                            mottaker_info = Note.query.filter_by(id = mottaker_int).first()
                            sender_totalt_belop =sender_info.data
                            mottaker_totalt_belop = mottaker_info.data
                            sender_totalt_belop_int = int(sender_totalt_belop)
                            mottaker_totalt_belop_int = int(mottaker_totalt_belop)

                            if sender_totalt_belop_int >= betaling_int:
                                ny_belop_sender = sender_totalt_belop_int -betaling_int
                                ny_belop_mottaker = mottaker_totalt_belop_int + betaling_int
                                sender_info.data =ny_belop_sender
                                db.session.commit()
                                mottaker_info.data =ny_belop_mottaker
                                db.session.commit()

                            else:
                                flash('Need more money', category='success')
                    else:
                        flash('Only numbers allowerd', category='success')
                else:
                    flash('0 is not a valid first number ', category='success')
            else:
                flash('Space is not a valid number', category='success')








    return render_template("home.html", user=current_user)


@views.route('/delete-note', methods=['POST'])
def delete_note():
    note = json.loads(request.data)
    noteId = note['noteId']
    note = Note.query.get(noteId)
    if note:
        if note.user_id == current_user.id:
            db.session.delete(note)
            db.session.commit()

    return jsonify({})
